#include <stdio.h>
#include <iostream>
#include <vector>
#include <fstream>
#include <iomanip>

using namespace std;

class SpectrumData
{
public:
	int SerialID;
	int SortID;
	double Spectrums[238];
    double Yield;
};

class DataGroup
{
public:
	int NumberID;
	char NucleiID[10];
	double Decay[18];
	int EnergyID[238];
    double PointSection[238][6];
};

class FissionData
{
public:
	char NucleiID[10];
	int Set;
	vector<double> EnergyPoint;
	vector<int> FissionID;
	vector<double> Ratio;
};


void InitialSpectrumData(vector<SpectrumData> &SingleSpectrum, int BatchSize)
{
	double Total = 0;
	for(int i=0; i<BatchSize; i++)
	{
		Total = 0;
		SingleSpectrum[i].SerialID=i+1;
    	for(int j=0; j<238; j++)
    	{
    		SingleSpectrum[i].Spectrums[j]= rand() % 100;
    		Total += SingleSpectrum[i].Spectrums[j];
    	}
    	for(int j=0; j<238; j++)
    	{
    		SingleSpectrum[i].Spectrums[j]= SingleSpectrum[i].Spectrums[j]/Total;
    	}
	}
}

void Crossover(vector<SpectrumData> &SingleSpectrum, int BatchSize)
{
	int P;
	double temp;
	double total1;
	double total2;
	int twenty = BatchSize * 0.2;
	for(int i=twenty; i<2*twenty; i++)
	{
		total1 = 0;
		total2 = 0;
		for(int j=0; j<20; j++)
		{
			P = rand() % 237;
			temp = SingleSpectrum[i].Spectrums[P];
			SingleSpectrum[i].Spectrums[P] = SingleSpectrum[BatchSize-twenty-1-i].Spectrums[P];
			SingleSpectrum[BatchSize-twenty-1-i].Spectrums[P] = temp;
		}
		for(int k=0; k<238; k++)
		{
			total1 = total1 + SingleSpectrum[i].Spectrums[k];
			total2 = total2 + SingleSpectrum[BatchSize-twenty-1-i].Spectrums[k];
		}
		for(int l=0; l<238; l++)
		{
			SingleSpectrum[i].Spectrums[l] = SingleSpectrum[i].Spectrums[l]/total1;
			SingleSpectrum[BatchSize-twenty-1-i].Spectrums[l] = SingleSpectrum[BatchSize-twenty-1-i].Spectrums[l]/total2;
		}
	}
}

void Mutation(vector<SpectrumData> &SingleSpectrum, int BatchSize)
{
	int P;
	double total;
	int sixty = BatchSize * 0.6;
	for(int i=sixty; i<BatchSize; i++)
	{
		total = 0;
		for(int j=0; j<20; j++)
		{
			P = rand() % 237;
			SingleSpectrum[i].Spectrums[P] = (rand() % 100) / 100;
		}
		for(int k=0; k<238; k++)
		{
			total = total + SingleSpectrum[i].Spectrums[k];
		}
		for(int l=0; l<238; l++)
		{
			SingleSpectrum[i].Spectrums[l] = SingleSpectrum[i].Spectrums[l]/total;
		}
	}
}

double ReadFromBurnup()
{
	double YieldofTb161;
	char skip[30];
    ifstream fin("inp.burn");
	    
	for(int k=0; k<15470; k++)
    {
        fin>>skip;
    }
	fin>>YieldofTb161;
	fin.close();
	return YieldofTb161;
}

void SortSpectrum(vector<SpectrumData> &SingleSpectrum, int BatchSize)
{
    SpectrumData temp;
   	for(int i=0; i<BatchSize; i++)
	{
        for(int j=i; j<BatchSize; j++)
    	{
       	    if(SingleSpectrum[i].Yield < SingleSpectrum[j].Yield)
        	{
    			temp = SingleSpectrum[i];
    			SingleSpectrum[i] = SingleSpectrum[j];
    			SingleSpectrum[j] = temp;
    		}
    	}
    }
}

void BuildDepthLib()
{
	ifstream fin("C:/Users/Administrator/Desktop/PointCross");
	ofstream fout("DepthMainLib");

    vector<DataGroup> Value;
    Value.resize(1487);
    for(int i=0; i<1487; i++)
    {
		fin>>Value[i].NumberID;
		fin>>Value[i].NucleiID;
		for(int m=0; m<18; m++)
		{
			fin>>Value[i].Decay[m];
		}
		for(int j=0; j<238; j++)
    	{
			fin>>Value[i].EnergyID[j];
        	for(int k=0; k<6; k++)
            {
        		fin>>Value[i].PointSection[j][k];
            }
    	}
	}
	
	char skip[10];
	for(int i=0; i<31; i++)
	{
	    fin>>skip;
	}
	vector<FissionData> Fission;
	Fission.resize(30);
    for(int i=0; i<30; i++)
    {
		fin>>Fission[i].NucleiID;
		fin>>skip;
		fin>>Fission[i].Set;
		
		Fission[i].EnergyPoint.resize(Fission[i].Set);
		for(int j=0; j<Fission[i].Set; j++)
		{
			fin>>Fission[i].EnergyPoint[j];
		}
	    Fission[i].FissionID.resize(1149);
        Fission[i].Ratio.resize(1149*Fission[i].Set);
		for(int k=0; k<1149; k++)
		{
			fin>>Fission[i].FissionID[k];
			for(int m=0; m<Fission[i].Set; m++)
			{
			    fin>>Fission[i].Ratio[k*Fission[i].Set+m];
			}
		}
		fin>>skip;
    }
	
	ifstream in("SpectrumData");
	double Spectrum[238];
	for(int i=0; i<238; i++)
	{
		in>>Spectrum[i];
	}

	fout<<"******************** Decay and cross-section data ********************"<<endl;
	for(int i=0;i<1487;i++)
	{
	    fout<<left<<setw(7)<<Value[i].NumberID<<" ";
		fout<<left<<setw(7)<<Value[i].NucleiID<<" ";
		for(int t=0; t<18; t++)
		{
			fout<<scientific<<setprecision(4)<<Value[i].Decay[t]<<"  ";
			if((t+1)%6==0)
			{
				fout<<endl;
				fout<<"                ";
			}
		}
		for(int z=0; z<6; z++)
		{
			double EnerDepCross = 0;
			for(int p=0 ; p<238; p++)
			{
			    EnerDepCross += Spectrum[p]*Value[i].PointSection[p][z];
			}
		    fout<<scientific<<setprecision(4)<<EnerDepCross<<"  ";
		}
		fout<<endl<<"                "<<-1<<endl;
	}

	fout<<-1<<endl<<"******************** Fission product yield data ********************"<<endl;
	fout<<30<<"      "<<endl<<"902270  902290  902320  912310  922320  922330  922340  922350  "<<endl;
	fout<<"922360  922370  922380  932370  932380  942380  942390  942400  "<<endl;
	fout<<"942410  942420  952410  952421  952430  962420  962430  962440  "<<endl;
	fout<<"962450  962460  962480  982490  982510  992540  "<<endl;

	for(int i=0; i<30; i++)
	{
		fout<<left<<setw(8)<<Fission[i].NucleiID<<1149<<"    "<<Fission[i].Set<<"       ";
		for(int j=0; j<Fission[i].Set; j++)
		{
			fout<<scientific<<setprecision(4)<<Fission[i].EnergyPoint[j]<<"  ";
		}
		for(int k=0; k<1149; k++)
		{
			if(k%4==0) fout<<endl<<"        ";
			fout<<left<<setw(8)<<Fission[i].FissionID[k];
			for(int m=0; m<Fission[i].Set; m++)
		    {
			    fout<<scientific<<setprecision(4)<<Fission[i].Ratio[k*Fission[i].Set+m]<<"  ";
		    }
		}
		fout<<-1<<endl;
	}
	fout<<-1;
	in.close();
	fin.close();
	fout.close();
}

int main()
{
	ofstream fout("out.txt");
	vector<SpectrumData> SingleSpectrum;
	int BatchSize = 200;
	SingleSpectrum.resize(BatchSize);

	for(int cycle=0; cycle<200; cycle++)
	{
		if(cycle==0) InitialSpectrumData(SingleSpectrum, BatchSize);

    	for(int i=0; i<BatchSize; i++)
    	{
    		ofstream fout2("SpectrumData");
//    		fout<<left<<setw(4)<<SingleSpectrum[i].SerialID<<" ";
    		for(int j=0; j<238; j++)
    		{
//    			fout<<scientific<<setprecision(4)<<SingleSpectrum[i].Spectrums[j]<<" ";
    			fout2<<scientific<<setprecision(6)<<SingleSpectrum[i].Spectrums[j]<<endl;
    		}
    		fout2.close();
    
    		BuildDepthLib();
    		system("RMC_Release_mpi.exe");
    
    		SingleSpectrum[i].Yield = ReadFromBurnup();
    
//    		fout<<scientific<<setprecision(6)<<SingleSpectrum[i].Yield<<endl;
    	}

		SortSpectrum(SingleSpectrum, BatchSize);
//    	fout<<"sorted:"<<endl;
    	for(int i=0; i<BatchSize; i++)
    	{
    		SingleSpectrum[i].SortID=i+1;
        	fout<<left<<setw(4)<<SingleSpectrum[i].SortID<<" "<<left<<setw(4)<<SingleSpectrum[i].SerialID<<" ";
    	    for(int j=0; j<238; j++)
    	    {
    	        fout<<scientific<<setprecision(4)<<SingleSpectrum[i].Spectrums[j]<<" ";
    	    }
    		fout<<scientific<<setprecision(6)<<SingleSpectrum[i].Yield<<endl;
    	}
		fout<<endl;
		
		Crossover(SingleSpectrum, BatchSize);
		Mutation(SingleSpectrum, BatchSize);
	}
			
    return 0;
}